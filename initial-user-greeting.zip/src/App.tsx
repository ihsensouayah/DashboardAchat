import React, { useState, useMemo } from 'react';
import { 
  Search, Upload, Clock, 
  CheckCircle, AlertCircle, Package, Calendar,
  ChevronDown, ChevronUp, X, Eye, Edit, RefreshCw,
  BarChart3, PieChart, ArrowUpRight, ArrowDownRight, Bell,
  Settings, Moon, Sun, Download, FileSpreadsheet, Plus,
  History, TrendingUp
} from 'lucide-react';
import * as XLSX from 'xlsx';

// Types
interface Order {
  id: string;
  reference: string;
  client: string;
  vehicle: string;
  vehicleBrand: string;
  task: string;
  lastUpdateBy: string;
  validationDate: string;
  delay: number;
  partsStatus: 'received' | 'pending' | 'delayed' | 'critical';
  estimatedDate: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  week: string;
  importDate: string;
}

interface WeekData {
  name: string;
  startDate: string;
  endDate: string;
  orderCount: number;
}

interface StatCard {
  title: string;
  value: number | string;
  change?: number;
  icon: React.ReactNode;
  color: string;
}

// Helper functions
const getWeekNumber = (date: Date): number => {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  return Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
};

const getWeekName = (date: Date): string => {
  const weekNum = getWeekNumber(date);
  const month = date.toLocaleString('fr-FR', { month: 'long' });
  const year = date.getFullYear();
  return `Semaine ${weekNum} - ${month.charAt(0).toUpperCase() + month.slice(1)} ${year}`;
};

const getWeekRange = (date: Date): { start: string; end: string } => {
  // Find the Monday of the week
  const day = date.getDay();
  const diff = date.getDate() - day + (day === 0 ? -6 : 1);
  const monday = new Date(date.setDate(diff));
  
  // Find the Sunday of the week
  const sunday = new Date(monday);
  sunday.setDate(monday.getDate() + 6);
  
  return {
    start: monday.toLocaleDateString('fr-FR'),
    end: sunday.toLocaleDateString('fr-FR')
  };
};

const extractVehicleBrand = (vehicle: string): string => {
  if (!vehicle) return '';
  // Extract brand from formats like "VOLKSWAGEN/POLO 4/3039 TU 97" or "RENAULT/RENAULT SYMBOLE/2480 TU 190"
  const parts = vehicle.split('/');
  if (parts.length > 0) {
    return parts[0].trim();
  }
  return vehicle.split(' ')[0] || vehicle;
};

const calculateDelay = (validationDate: string): number => {
  if (!validationDate) return 0;
  const validation = new Date(validationDate);
  const today = new Date();
  const diffTime = Math.abs(today.getTime() - validation.getTime());
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return diffDays;
};

const determinePartsStatus = (delay: number): Order['partsStatus'] => {
  if (delay <= 5) return 'received';
  if (delay <= 10) return 'pending';
  if (delay <= 14) return 'delayed';
  return 'critical';
};

const determinePriority = (delay: number): Order['priority'] => {
  if (delay <= 5) return 'low';
  if (delay <= 10) return 'medium';
  if (delay <= 14) return 'high';
  return 'urgent';
};

// Mock Data - simulating uploaded data
const mockOrders: Order[] = [
  { id: '1', reference: 'DS1441/2026', client: 'STAR ASSURANCES', vehicle: 'VOLKSWAGEN/POLO 4/3039 TU 97', vehicleBrand: 'VOLKSWAGEN', task: 'Commande et Réservation Pièces de rechange', lastUpdateBy: 'Iheb Draoui', validationDate: '2026-04-22 09:33:35', delay: 8, partsStatus: 'pending', estimatedDate: '2026-05-05', priority: 'medium', week: 'Semaine 17 - Avril 2026', importDate: '2026-04-28' },
  { id: '2', reference: 'DS1442/2026', client: 'STAR ASSURANCES', vehicle: 'VOLKSWAGEN/BORA/8867 TU 98', vehicleBrand: 'VOLKSWAGEN', task: 'Commande et Réservation Pièces de rechange', lastUpdateBy: 'Iheb Draoui', validationDate: '2026-04-24 10:15:11', delay: 6, partsStatus: 'pending', estimatedDate: '2026-05-06', priority: 'medium', week: 'Semaine 17 - Avril 2026', importDate: '2026-04-28' },
  { id: '3', reference: 'DS1444/2026', client: 'STAR ASSURANCES', vehicle: 'TOYOTA/AGYA/9069 TU 237', vehicleBrand: 'TOYOTA', task: 'Commande et Réservation Pièces de rechange', lastUpdateBy: 'Olfa Zribi', validationDate: '2026-04-21 12:47:02', delay: 9, partsStatus: 'pending', estimatedDate: '2026-05-04', priority: 'medium', week: 'Semaine 17 - Avril 2026', importDate: '2026-04-28' },
  { id: '4', reference: 'DS1423/2026', client: 'STAR ASSURANCES', vehicle: 'CITROEN/BERLINGO/9924 TU 243', vehicleBrand: 'CITROEN', task: 'Commande et Réservation Pièces de rechange', lastUpdateBy: 'Houssem Eddine BEN ROUHA', validationDate: '2026-04-23 08:48:10', delay: 7, partsStatus: 'pending', estimatedDate: '2026-05-05', priority: 'medium', week: 'Semaine 17 - Avril 2026', importDate: '2026-04-28' },
  { id: '5', reference: 'DS1427/2026', client: 'STAR ASSURANCES', vehicle: 'PEUGEOT/206/7973 TU 112', vehicleBrand: 'PEUGEOT', task: 'Commande et Réservation Pièces de rechange', lastUpdateBy: 'Achref Zehiri', validationDate: '2026-04-21 15:22:52', delay: 9, partsStatus: 'pending', estimatedDate: '2026-05-04', priority: 'medium', week: 'Semaine 17 - Avril 2026', importDate: '2026-04-28' },
  { id: '6', reference: 'DS1429/2026', client: 'STAR ASSURANCES', vehicle: 'GEELY/GC6/3408 TU 227', vehicleBrand: 'GEELY', task: 'Commande et Réservation Pièces de rechange', lastUpdateBy: 'Nada Aydi', validationDate: '2026-04-24 00:00:00', delay: 6, partsStatus: 'pending', estimatedDate: '2026-05-06', priority: 'medium', week: 'Semaine 17 - Avril 2026', importDate: '2026-04-28' },
  { id: '7', reference: 'DS1388/2026', client: 'STAR ASSURANCES', vehicle: 'PEUGEOT/308/6865 TU 170', vehicleBrand: 'PEUGEOT', task: 'Commande et Réservation Pièces de rechange', lastUpdateBy: 'Houssem Eddine BEN ROUHA', validationDate: '2026-04-22 16:09:14', delay: 8, partsStatus: 'pending', estimatedDate: '2026-05-05', priority: 'medium', week: 'Semaine 17 - Avril 2026', importDate: '2026-04-28' },
  { id: '8', reference: 'DS1394/2026', client: 'STAR ASSURANCES', vehicle: 'RENAULT/RENAULT SYMBOLE/2480 TU 190', vehicleBrand: 'RENAULT', task: 'Commande et Réservation Pièces de rechange', lastUpdateBy: 'Emna Elaloui', validationDate: '2026-04-23 14:52:43', delay: 7, partsStatus: 'pending', estimatedDate: '2026-05-05', priority: 'medium', week: 'Semaine 17 - Avril 2026', importDate: '2026-04-28' },
  { id: '9', reference: 'DS1396/2026', client: 'STAR ASSURANCES', vehicle: 'SSANGYONG/ACTYON/5916 TU 153', vehicleBrand: 'SSANGYONG', task: 'Commande et Réservation Pièces de rechange', lastUpdateBy: 'Marwa Yaferni', validationDate: '2026-04-22 14:52:23', delay: 8, partsStatus: 'pending', estimatedDate: '2026-05-05', priority: 'medium', week: 'Semaine 17 - Avril 2026', importDate: '2026-04-28' },
  { id: '10', reference: 'DS1359/2026', client: 'STAR ASSURANCES', vehicle: 'VOLKSWAGEN/PASSAT/7926 TU 175', vehicleBrand: 'VOLKSWAGEN', task: 'Commande et Réservation Pièces de rechange', lastUpdateBy: 'Iheb Draoui', validationDate: '2026-04-21 10:15:33', delay: 9, partsStatus: 'pending', estimatedDate: '2026-05-04', priority: 'medium', week: 'Semaine 17 - Avril 2026', importDate: '2026-04-28' },
  { id: '11', reference: 'DS1325/2026', client: 'STAR ASSURANCES', vehicle: 'SEAT/SEAT/984 TU 242', vehicleBrand: 'SEAT', task: 'Commande et Réservation Pièces de rechange', lastUpdateBy: 'Iheb Draoui', validationDate: '2026-04-17 09:41:30', delay: 13, partsStatus: 'delayed', estimatedDate: '2026-05-02', priority: 'high', week: 'Semaine 16 - Avril 2026', importDate: '2026-04-21' },
  { id: '12', reference: 'DS1332/2026', client: 'STAR ASSURANCES', vehicle: 'FIAT/FIAT/ PUNTO/6902 TU 130', vehicleBrand: 'FIAT', task: 'Commande et Réservation Pièces de rechange', lastUpdateBy: 'Nada Aydi', validationDate: '2026-04-20 16:04:03', delay: 10, partsStatus: 'pending', estimatedDate: '2026-05-03', priority: 'medium', week: 'Semaine 16 - Avril 2026', importDate: '2026-04-21' },
  { id: '13', reference: 'DS1293/2026', client: 'MAE ASSURANCES', vehicle: 'NISSAN/JUKE/6994 TU 259', vehicleBrand: 'NISSAN', task: 'Commande et Réservation Pièces de rechange', lastUpdateBy: 'Ons Ouni', validationDate: '2026-04-22 09:05:09', delay: 8, partsStatus: 'pending', estimatedDate: '2026-05-05', priority: 'medium', week: 'Semaine 17 - Avril 2026', importDate: '2026-04-28' },
];

function App() {
  const [orders, setOrders] = useState<Order[]>(mockOrders);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [sortField, setSortField] = useState<keyof Order>('delay');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [selectedWeek, setSelectedWeek] = useState<string>('all');
  const [uploadHistory, setUploadHistory] = useState<WeekData[]>([
    { name: 'Semaine 17 - Avril 2026', startDate: '21/04/2026', endDate: '27/04/2026', orderCount: 10 },
    { name: 'Semaine 16 - Avril 2026', startDate: '14/04/2026', endDate: '20/04/2026', orderCount: 3 },
    { name: 'Semaine 15 - Avril 2026', startDate: '07/04/2026', endDate: '13/04/2026', orderCount: 8 },
    { name: 'Semaine 14 - Avril 2026', startDate: '31/03/2026', endDate: '06/04/2026', orderCount: 12 },
  ]);
  const [lastUploadDate, setLastUploadDate] = useState<string>('28/04/2026');

  // Calculate statistics
  const stats = useMemo(() => {
    const filtered = selectedWeek === 'all' ? orders : orders.filter(o => o.week === selectedWeek);
    const total = filtered.length;
    const received = filtered.filter(o => o.partsStatus === 'received').length;
    const delayed = filtered.filter(o => o.partsStatus === 'delayed' || o.partsStatus === 'critical').length;
    const avgDelay = filtered.reduce((acc, o) => acc + o.delay, 0) / total || 0;
    const critical = filtered.filter(o => o.partsStatus === 'critical').length;
    
    return { total, received, delayed, avgDelay, critical };
  }, [orders, selectedWeek]);

  // Filter and sort orders
  const filteredOrders = useMemo(() => {
    return orders
      .filter(order => {
        const matchesSearch = order.reference.toLowerCase().includes(searchTerm.toLowerCase()) ||
          order.client.toLowerCase().includes(searchTerm.toLowerCase()) ||
          order.vehicleBrand.toLowerCase().includes(searchTerm.toLowerCase()) ||
          order.lastUpdateBy.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesStatus = statusFilter === 'all' || order.partsStatus === statusFilter;
        const matchesPriority = priorityFilter === 'all' || order.priority === priorityFilter;
        const matchesWeek = selectedWeek === 'all' || order.week === selectedWeek;
        return matchesSearch && matchesStatus && matchesPriority && matchesWeek;
      })
      .sort((a, b) => {
        const aVal = a[sortField];
        const bVal = b[sortField];
        if (typeof aVal === 'string' && typeof bVal === 'string') {
          return sortDirection === 'asc' ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
        }
        return sortDirection === 'asc' ? (aVal as number) - (bVal as number) : (bVal as number) - (aVal as number);
      });
  }, [orders, searchTerm, statusFilter, priorityFilter, sortField, sortDirection, selectedWeek]);

  // Handle sort
  const handleSort = (field: keyof Order) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('desc');
    }
  };

  // Handle file drop
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      processExcelFile(files[0]);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      processExcelFile(files[0]);
    }
  };

  const processExcelFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const data = event.target?.result;
      if (data) {
        const workbook = XLSX.read(data, { type: 'binary' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet);
        
        // Transform Excel data to Order format
        const newOrders: Order[] = jsonData.map((row: any, index: number) => {
          const validationDate = row['Date Validation Expert'] || row['date_validation_expert'] || new Date().toISOString();
          const delay = calculateDelay(validationDate);
          const vehicle = row['Véhicule'] || row['vehicule'] || row['Vehicle'] || '';
          
          return {
            id: `new-${Date.now()}-${index}`,
            reference: row['Référence interne'] || row['reference_interne'] || row['Reference'] || `REF-${Date.now()}-${index}`,
            client: row['Client'] || row['client'] || row['Client'] || 'Client inconnu',
            vehicle: vehicle,
            vehicleBrand: extractVehicleBrand(vehicle),
            task: row['Tâche courante'] || row['tache_courante'] || row['Task'] || 'Tâche non spécifiée',
            lastUpdateBy: row['Dernière mise à jour par'] || row['derniere_mise_a_jour_par'] || row['LastUpdateBy'] || 'Inconnu',
            validationDate: validationDate,
            delay: delay,
            partsStatus: determinePartsStatus(delay),
            estimatedDate: new Date(new Date().getTime() + delay * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
            priority: determinePriority(delay),
            week: getWeekName(new Date()),
            importDate: new Date().toISOString().split('T')[0]
          };
        });

        // Update upload history
        const currentWeek = getWeekName(new Date());
        const weekRange = getWeekRange(new Date());
        setUploadHistory(prev => [
          { 
            name: currentWeek, 
            startDate: weekRange.start, 
            endDate: weekRange.end, 
            orderCount: newOrders.length 
          },
          ...prev
        ]);
        setLastUploadDate(new Date().toLocaleDateString('fr-FR'));
        
        // Add new orders
        setOrders(prev => [...newOrders, ...prev]);
      }
    };
    reader.readAsBinaryString(file);
  };

  // Get status color
  const getStatusColor = (status: Order['partsStatus']) => {
    switch (status) {
      case 'received': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'pending': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      case 'delayed': return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200';
      case 'critical': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
    }
  };

  const getPriorityColor = (priority: Order['priority']) => {
    switch (priority) {
      case 'low': return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      case 'high': return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200';
      case 'urgent': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
    }
  };

  const statCards: StatCard[] = [
    { title: 'Total Dossiers', value: stats.total, change: 12, icon: <FileSpreadsheet className="w-6 h-6" />, color: 'blue' },
    { title: 'Pièces Reçues', value: stats.received, change: 8, icon: <CheckCircle className="w-6 h-6" />, color: 'green' },
    { title: 'En Retard', value: stats.delayed, change: -5, icon: <AlertCircle className="w-6 h-6" />, color: 'orange' },
    { title: 'Délai Moyen', value: `${stats.avgDelay.toFixed(1)}j`, change: -2, icon: <Clock className="w-6 h-6" />, color: 'purple' },
  ];

  return (
    <div className={`min-h-screen transition-colors duration-300 ${isDarkMode ? 'dark bg-gray-900' : 'bg-gray-50'}`}>
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
                  <Package className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-900 dark:text-white">OrderFlow</h1>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Suivi Commandes & Pièces</p>
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <button className="relative p-2 text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700 rounded-lg transition-colors">
                <Bell className="w-5 h-5" />
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center animate-pulse">
                  3
                </span>
              </button>
              <button
                onClick={() => setIsDarkMode(!isDarkMode)}
                className="p-2 text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700 rounded-lg transition-colors"
              >
                {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </button>
              <button className="p-2 text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700 rounded-lg transition-colors">
                <Settings className="w-5 h-5" />
              </button>
              <div className="w-8 h-8 bg-gradient-to-br from-green-400 to-blue-500 rounded-full flex items-center justify-center text-white font-medium text-sm">
                SM
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {statCards.map((stat, index) => (
            <div
              key={index}
              className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{stat.title}</p>
                  <p className="text-3xl font-bold text-gray-900 dark:text-white mt-1">{stat.value}</p>
                  {stat.change !== undefined && (
                    <div className={`flex items-center mt-2 text-sm ${stat.change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {stat.change >= 0 ? <ArrowUpRight className="w-4 h-4 mr-1" /> : <ArrowDownRight className="w-4 h-4 mr-1" />}
                      <span>{Math.abs(stat.change)}% vs semaine dernière</span>
                    </div>
                  )}
                </div>
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                  stat.color === 'blue' ? 'bg-blue-100 text-blue-600 dark:bg-blue-900 dark:text-blue-400' :
                  stat.color === 'green' ? 'bg-green-100 text-green-600 dark:bg-green-900 dark:text-green-400' :
                  stat.color === 'orange' ? 'bg-orange-100 text-orange-600 dark:bg-orange-900 dark:text-orange-400' :
                  'bg-purple-100 text-purple-600 dark:bg-purple-900 dark:text-purple-400'
                }`}>
                  {stat.icon}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Upload Zone */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* File Upload */}
          <div className="lg:col-span-2">
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`border-2 border-dashed rounded-2xl p-8 text-center transition-all duration-300 ${
                isDragging
                  ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20 scale-[1.02]'
                  : 'border-gray-300 dark:border-gray-600 hover:border-blue-400 dark:hover:border-blue-500'
              }`}
            >
              <div className="flex flex-col items-center">
                <div className={`w-16 h-16 rounded-full flex items-center justify-center mb-4 transition-all duration-300 ${
                  isDragging ? 'bg-blue-500 scale-110' : 'bg-gray-100 dark:bg-gray-700'
                }`}>
                  <Upload className={`w-8 h-8 ${isDragging ? 'text-white' : 'text-gray-400'}`} />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  Importer l'état des dossiers (Odoo .xlsx)
                </h3>
                <p className="text-gray-500 dark:text-gray-400 mb-4">
                  Glissez votre fichier Excel ici ou cliquez pour choisir
                </p>
                <label className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors flex items-center space-x-2 cursor-pointer">
                  <FileSpreadsheet className="w-4 h-4" />
                  <span>Sélectionner un fichier</span>
                  <input
                    type="file"
                    accept=".xlsx,.xls"
                    onChange={handleFileSelect}
                    className="hidden"
                  />
                </label>
                <p className="text-xs text-gray-400 dark:text-gray-500 mt-3">
                  Dernière mise à jour : {lastUploadDate}
                </p>
              </div>
            </div>
          </div>

          {/* Upload History */}
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-sm border border-gray-200 dark:border-gray-700">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center space-x-2">
              <History className="w-5 h-5 text-blue-600" />
              <span>Historique des imports</span>
            </h3>
            <div className="space-y-3">
              {uploadHistory.slice(0, 4).map((week, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedWeek(week.name)}
                  className={`w-full p-3 rounded-xl text-left transition-all duration-200 ${
                    selectedWeek === week.name
                      ? 'bg-blue-100 dark:bg-blue-900 border-2 border-blue-500'
                      : 'bg-gray-50 dark:bg-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 border-2 border-transparent'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-gray-900 dark:text-white text-sm">{week.name}</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">{week.startDate} - {week.endDate}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold text-blue-600 dark:text-blue-400">{week.orderCount}</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">dossiers</p>
                    </div>
                  </div>
                </button>
              ))}
            </div>
            <button
              onClick={() => setSelectedWeek('all')}
              className={`w-full mt-3 p-3 rounded-xl text-center transition-all duration-200 ${
                selectedWeek === 'all'
                  ? 'bg-blue-100 dark:bg-blue-900 border-2 border-blue-500 text-blue-700 dark:text-blue-300 font-medium'
                  : 'bg-gray-50 dark:bg-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 text-gray-600 dark:text-gray-300'
              }`}
            >
              Voir tous les dossiers
            </button>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-sm border border-gray-200 dark:border-gray-700 mb-6">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div className="flex flex-col sm:flex-row gap-4 flex-1">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Rechercher (référence, client, véhicule, chargé d'achat)..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white transition-all"
                />
              </div>
              <div className="flex gap-2">
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white transition-all"
                >
                  <option value="all">Tous les statuts</option>
                  <option value="received">Reçues</option>
                  <option value="pending">En attente</option>
                  <option value="delayed">En retard</option>
                  <option value="critical">Critique</option>
                </select>
                <select
                  value={priorityFilter}
                  onChange={(e) => setPriorityFilter(e.target.value)}
                  className="px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white transition-all"
                >
                  <option value="all">Toutes priorités</option>
                  <option value="low">Basse</option>
                  <option value="medium">Moyenne</option>
                  <option value="high">Haute</option>
                  <option value="urgent">Urgente</option>
                </select>
              </div>
            </div>
            <div className="flex gap-2">
              <button className="px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors flex items-center space-x-2">
                <Download className="w-4 h-4" />
                <span>Exporter</span>
              </button>
              <button className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl transition-colors flex items-center space-x-2">
                <Plus className="w-4 h-4" />
                <span>Nouveau dossier</span>
              </button>
            </div>
          </div>
        </div>

        {/* Orders Table */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
          <div className="p-6 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
            <div>
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
                Commandes & Réservation Pièces de Rechange
              </h2>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                {filteredOrders.length} dossiers {selectedWeek !== 'all' ? `pour ${selectedWeek}` : ''}
              </p>
            </div>
            <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
              <RefreshCw className="w-5 h-5 text-gray-500" />
            </button>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 dark:bg-gray-700">
                <tr>
                  {[
                    { key: 'reference', label: 'Référence' },
                    { key: 'client', label: 'Client' },
                    { key: 'vehicleBrand', label: 'Véhicule (Marque)' },
                    { key: 'task', label: 'Tâche' },
                    { key: 'lastUpdateBy', label: 'Dernière mise à jour par' },
                    { key: 'validationDate', label: 'Date Valid. Expert' },
                    { key: 'delay', label: 'Délai (j)' },
                    { key: 'partsStatus', label: 'Situation' },
                  ].map((col) => (
                    <th
                      key={col.key}
                      onClick={() => handleSort(col.key as keyof Order)}
                      className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors"
                    >
                      <div className="flex items-center space-x-1">
                        <span>{col.label}</span>
                        {sortField === col.key && (
                          sortDirection === 'asc' ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />
                        )}
                      </div>
                    </th>
                  ))}
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                {filteredOrders.map((order, index) => (
                  <tr
                    key={order.id}
                    className="hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors cursor-pointer"
                    onClick={() => {
                      setSelectedOrder(order);
                      setIsModalOpen(true);
                    }}
                    style={{ animationDelay: `${index * 50}ms` }}
                  >
                    <td className="px-4 py-4 whitespace-nowrap">
                      <span className="text-sm font-medium text-blue-600 dark:text-blue-400">{order.reference}</span>
                    </td>
                    <td className="px-4 py-4 whitespace-nowrap">
                      <span className="text-sm text-gray-900 dark:text-white">{order.client}</span>
                    </td>
                    <td className="px-4 py-4 whitespace-nowrap">
                      <span className="text-sm font-medium text-gray-900 dark:text-white">{order.vehicleBrand}</span>
                    </td>
                    <td className="px-4 py-4 whitespace-nowrap max-w-xs">
                      <span className="text-sm text-gray-900 dark:text-white truncate block">{order.task}</span>
                    </td>
                    <td className="px-4 py-4 whitespace-nowrap">
                      <div className="flex items-center space-x-2">
                        <div className="w-7 h-7 bg-gradient-to-br from-purple-400 to-pink-500 rounded-full flex items-center justify-center text-white text-xs font-medium">
                          {order.lastUpdateBy.split(' ').map(n => n[0]).join('').substring(0, 2)}
                        </div>
                        <span className="text-sm text-gray-900 dark:text-white">{order.lastUpdateBy}</span>
                      </div>
                    </td>
                    <td className="px-4 py-4 whitespace-nowrap">
                      <div className="flex items-center space-x-2">
                        <Calendar className="w-4 h-4 text-gray-400" />
                        <span className="text-sm text-gray-900 dark:text-white">{order.validationDate.split(' ')[0]}</span>
                      </div>
                    </td>
                    <td className="px-4 py-4 whitespace-nowrap">
                      <div className="flex items-center space-x-2">
                        <span className={`text-sm font-bold ${order.delay > 14 ? 'text-red-600' : order.delay > 10 ? 'text-orange-600' : order.delay > 5 ? 'text-yellow-600' : 'text-green-600'}`}>
                          {order.delay}j
                        </span>
                        {order.delay > 14 && <AlertCircle className="w-4 h-4 text-red-500" />}
                      </div>
                    </td>
                    <td className="px-4 py-4 whitespace-nowrap">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium capitalize ${getStatusColor(order.partsStatus)}`}>
                        {order.partsStatus === 'received' && '✓ Reçues'}
                        {order.partsStatus === 'pending' && ' En attente'}
                        {order.partsStatus === 'delayed' && '⚠ En retard'}
                        {order.partsStatus === 'critical' && '🔴 Critique'}
                      </span>
                    </td>
                    <td className="px-4 py-4 whitespace-nowrap text-right">
                      <div className="flex items-center justify-end space-x-2">
                        <button className="p-2 hover:bg-blue-100 dark:hover:bg-blue-900 rounded-lg transition-colors">
                          <Eye className="w-4 h-4 text-blue-600" />
                        </button>
                        <button className="p-2 hover:bg-green-100 dark:hover:bg-green-900 rounded-lg transition-colors">
                          <Edit className="w-4 h-4 text-green-600" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="p-6 border-t border-gray-200 dark:border-gray-700 flex items-center justify-between">
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Affichage de 1 à {filteredOrders.length} sur {filteredOrders.length} résultats
            </p>
            <div className="flex space-x-2">
              <button className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-sm hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors disabled:opacity-50" disabled>
                Précédent
              </button>
              <button className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm">1</button>
              <button className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-sm hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                2
              </button>
              <button className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-sm hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                Suivant
              </button>
            </div>
          </div>
        </div>

        {/* Analytics Section */}
        <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Status Distribution */}
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-sm border border-gray-200 dark:border-gray-700">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-6 flex items-center space-x-2">
              <PieChart className="w-5 h-5 text-blue-600" />
              <span>Répartition par statut</span>
            </h3>
            <div className="space-y-4">
              {[
                { status: 'Reçues', count: orders.filter(o => o.partsStatus === 'received').length, color: 'bg-green-500', percentage: (orders.filter(o => o.partsStatus === 'received').length / orders.length) * 100 },
                { status: 'En attente', count: orders.filter(o => o.partsStatus === 'pending').length, color: 'bg-blue-500', percentage: (orders.filter(o => o.partsStatus === 'pending').length / orders.length) * 100 },
                { status: 'En retard', count: orders.filter(o => o.partsStatus === 'delayed').length, color: 'bg-orange-500', percentage: (orders.filter(o => o.partsStatus === 'delayed').length / orders.length) * 100 },
                { status: 'Critique', count: orders.filter(o => o.partsStatus === 'critical').length, color: 'bg-red-500', percentage: (orders.filter(o => o.partsStatus === 'critical').length / orders.length) * 100 },
              ].map((item) => (
                <div key={item.status}>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-600 dark:text-gray-400">{item.status}</span>
                    <span className="font-medium text-gray-900 dark:text-white">{item.count} ({item.percentage.toFixed(0)}%)</span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-3">
                    <div
                      className={`${item.color} h-3 rounded-full transition-all duration-500`}
                      style={{ width: `${item.percentage}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Delay Distribution */}
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-sm border border-gray-200 dark:border-gray-700">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-6 flex items-center space-x-2">
              <BarChart3 className="w-5 h-5 text-purple-600" />
              <span>Délais d'achat</span>
            </h3>
            <div className="flex items-end justify-around h-48 px-4">
              {[
                { label: '≤5j', count: orders.filter(o => o.delay <= 5).length, color: 'bg-green-500' },
                { label: '6-10j', count: orders.filter(o => o.delay > 5 && o.delay <= 10).length, color: 'bg-yellow-500' },
                { label: '11-14j', count: orders.filter(o => o.delay > 10 && o.delay <= 14).length, color: 'bg-orange-500' },
                { label: '>14j', count: orders.filter(o => o.delay > 14).length, color: 'bg-red-500' },
              ].map((item) => (
                <div key={item.label} className="flex flex-col items-center">
                  <div className="text-sm font-bold text-gray-900 dark:text-white mb-2">{item.count}</div>
                  <div
                    className={`${item.color} w-14 rounded-t-lg transition-all duration-500 hover:opacity-80`}
                    style={{ height: `${Math.max((item.count / orders.length) * 150, 20)}px` }}
                  />
                  <div className="text-xs text-gray-500 dark:text-gray-400 mt-2 text-center font-medium">{item.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Chargés d'achat Stats */}
        <div className="mt-8 bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-sm border border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-6 flex items-center space-x-2">
            <TrendingUp className="w-5 h-5 text-green-600" />
            <span>Performance par chargé d'achat</span>
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[...new Set(orders.map(o => o.lastUpdateBy))].slice(0, 8).map((manager) => {
              const managerOrders = orders.filter(o => o.lastUpdateBy === manager);
              const avgDelay = managerOrders.reduce((acc, o) => acc + o.delay, 0) / managerOrders.length;
              return (
                <div key={manager} className="p-4 bg-gray-50 dark:bg-gray-700 rounded-xl">
                  <div className="flex items-center space-x-3 mb-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-purple-400 to-pink-500 rounded-full flex items-center justify-center text-white font-medium text-sm">
                      {manager.split(' ').map(n => n[0]).join('').substring(0, 2)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-gray-900 dark:text-white text-sm truncate">{manager}</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">{managerOrders.length} dossiers</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-500 dark:text-gray-400">Délai moyen</span>
                    <span className={`font-bold ${avgDelay > 14 ? 'text-red-600' : avgDelay > 10 ? 'text-orange-600' : 'text-green-600'}`}>
                      {avgDelay.toFixed(1)}j
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </main>

      {/* Modal */}
      {isModalOpen && selectedOrder && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:p-0">
            <div
              className="fixed inset-0 transition-opacity bg-gray-500 bg-opacity-75"
              onClick={() => setIsModalOpen(false)}
            />
            <div className="relative inline-block w-full max-w-2xl p-6 my-8 text-left align-middle transition-all transform bg-white dark:bg-gray-800 shadow-xl rounded-2xl">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
                  Détails du dossier
                </h3>
                <button
                  onClick={() => setIsModalOpen(false)}
                  className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                >
                  <X className="w-5 h-5 text-gray-500" />
                </button>
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="text-sm text-gray-500 dark:text-gray-400">Référence</label>
                  <p className="font-medium text-gray-900 dark:text-white">{selectedOrder.reference}</p>
                </div>
                <div>
                  <label className="text-sm text-gray-500 dark:text-gray-400">Client</label>
                  <p className="font-medium text-gray-900 dark:text-white">{selectedOrder.client}</p>
                </div>
                <div>
                  <label className="text-sm text-gray-500 dark:text-gray-400">Véhicule (Marque)</label>
                  <p className="font-medium text-gray-900 dark:text-white">{selectedOrder.vehicleBrand}</p>
                </div>
                <div>
                  <label className="text-sm text-gray-500 dark:text-gray-400">Véhicule (Complet)</label>
                  <p className="font-medium text-gray-900 dark:text-white text-sm">{selectedOrder.vehicle}</p>
                </div>
                <div className="col-span-2">
                  <label className="text-sm text-gray-500 dark:text-gray-400">Tâche</label>
                  <p className="font-medium text-gray-900 dark:text-white">{selectedOrder.task}</p>
                </div>
                <div>
                  <label className="text-sm text-gray-500 dark:text-gray-400">Dernière mise à jour par</label>
                  <p className="font-medium text-gray-900 dark:text-white">{selectedOrder.lastUpdateBy}</p>
                </div>
                <div>
                  <label className="text-sm text-gray-500 dark:text-gray-400">Date Validation Expert</label>
                  <p className="font-medium text-gray-900 dark:text-white">{selectedOrder.validationDate}</p>
                </div>
                <div>
                  <label className="text-sm text-gray-500 dark:text-gray-400">Délai d'achat (jours)</label>
                  <p className={`font-bold text-lg ${selectedOrder.delay > 14 ? 'text-red-600' : selectedOrder.delay > 10 ? 'text-orange-600' : 'text-green-600'}`}>
                    {selectedOrder.delay} jours
                  </p>
                </div>
                <div>
                  <label className="text-sm text-gray-500 dark:text-gray-400">Statut Pièces</label>
                  <span className={`px-3 py-1 rounded-full text-xs font-medium capitalize ${getStatusColor(selectedOrder.partsStatus)}`}>
                    {selectedOrder.partsStatus}
                  </span>
                </div>
                <div>
                  <label className="text-sm text-gray-500 dark:text-gray-400">Priorité</label>
                  <span className={`px-3 py-1 rounded-full text-xs font-medium capitalize ${getPriorityColor(selectedOrder.priority)}`}>
                    {selectedOrder.priority}
                  </span>
                </div>
                <div>
                  <label className="text-sm text-gray-500 dark:text-gray-400">Semaine</label>
                  <p className="font-medium text-gray-900 dark:text-white">{selectedOrder.week}</p>
                </div>
                <div>
                  <label className="text-sm text-gray-500 dark:text-gray-400">Date Import</label>
                  <p className="font-medium text-gray-900 dark:text-white">{selectedOrder.importDate}</p>
                </div>
              </div>

              <div className="mt-6 flex justify-end space-x-3">
                <button
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                >
                  Fermer
                </button>
                <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors flex items-center space-x-2">
                  <Edit className="w-4 h-4" />
                  <span>Modifier</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
